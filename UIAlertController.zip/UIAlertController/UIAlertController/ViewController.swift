//
//  ViewController.swift
//  UIAlertController
//
//  Created by Abhishek Verma on 14/05/17.
//  Copyright © 2017 Abhishek Verma. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func SimpleAlert(_ sender: Any) {
        let alert = UIAlertController(title: "SWIFT Hub", message: "SWIFT Hub IOS Tutorials", preferredStyle: .alert)
        let cancel = UIAlertAction(title: "Cancel", style: .cancel) { (cancel) in
            print("Cancel Successfully")
        }
        alert.addAction(cancel)
        self.present(alert, animated: true, completion: nil)
    }
    @IBAction func AlertActionSheet(_ sender: Any) {
        let alertactionsheet = UIAlertController(title: "SWIFT Hub IOS Tutorials", message: nil, preferredStyle: .actionSheet)
        let facebook = UIAlertAction(title: "Facebook", style: .default) { (facebook) in
            print("Facebook Click Successfully")
        }
        let google = UIAlertAction(title: "Google+", style: .default) { (google) in
            print("Google+ Click Successfully")
        }
        let twitter = UIAlertAction(title: "Twitter", style: .default) { (twiter) in
            print("Twitter Click Successfully")
        }
        let whatsapp = UIAlertAction(title: "WhatsApp", style: .default) { (whatsapp) in
            print("WhatsApp Click Successfully")
        }
        let cancel = UIAlertAction(title: "Cancel", style: .cancel) { (cancel) in
            print("Cancel Successfully")
        }
        alertactionsheet.addAction(facebook)
        alertactionsheet.addAction(google)
        alertactionsheet.addAction(twitter)
        alertactionsheet.addAction(whatsapp)
        alertactionsheet.addAction(cancel)
        self.present(alertactionsheet, animated: true, completion: nil)
    }

}

